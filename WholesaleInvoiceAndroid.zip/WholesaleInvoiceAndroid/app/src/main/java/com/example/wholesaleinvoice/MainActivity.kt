package com.example.wholesaleinvoice

import android.content.ContentValues
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class InvoiceLine(val name: String, val qty: Double, val rate: Double) {
    val amount get() = qty * rate
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { InvoiceScreen() } }
    }
}

@Composable
fun InvoiceScreen() {
    val context = LocalContext.current
    var seller by remember { mutableStateOf("Your Business Name") }
    var sellerGstin by remember { mutableStateOf("") }
    var buyer by remember { mutableStateOf("") }
    var buyerGstin by remember { mutableStateOf("") }
    var invoiceNo by remember { mutableStateOf("INV-${System.currentTimeMillis().toString().takeLast(6)}") }
    var product by remember { mutableStateOf("") }
    var qty by remember { mutableStateOf("1") }
    var rate by remember { mutableStateOf("0") }
    var gst by remember { mutableStateOf("18") }
    var discount by remember { mutableStateOf("0") }
    var place by remember { mutableStateOf("") }
    var lines by remember { mutableStateOf(listOf<InvoiceLine>()) }

    val subtotal = lines.sumOf { it.amount }
    val discountValue = discount.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val taxable = (subtotal - discountValue).coerceAtLeast(0.0)
    val gstRate = gst.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val tax = taxable * gstRate / 100.0
    val total = taxable + tax
    val date = SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(Date())

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("WHOLESALE INVOICE", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("GST billing • Indian Rupees (₹)")
        OutlinedTextField(seller, { seller = it }, label = { Text("Your business name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(sellerGstin, { sellerGstin = it }, label = { Text("Your GSTIN") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(invoiceNo, { invoiceNo = it }, label = { Text("Invoice number") }, modifier = Modifier.fillMaxWidth())
        Text("Date: $date", fontWeight = FontWeight.SemiBold)
        HorizontalDivider()
        Text("BILL TO", fontWeight = FontWeight.Bold)
        OutlinedTextField(buyer, { buyer = it }, label = { Text("Customer / buyer name") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(buyerGstin, { buyerGstin = it }, label = { Text("Buyer GSTIN (optional)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(place, { place = it }, label = { Text("Place of supply / state") }, modifier = Modifier.fillMaxWidth())
        HorizontalDivider()
        Text("ADD ITEMS", fontWeight = FontWeight.Bold)
        OutlinedTextField(product, { product = it }, label = { Text("Product / description") }, modifier = Modifier.fillMaxWidth())
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(qty, { qty = it }, label = { Text("Qty") }, modifier = Modifier.weight(1f))
            OutlinedTextField(rate, { rate = it }, label = { Text("Rate ₹") }, modifier = Modifier.weight(1f))
        }
        Button(onClick = {
            val q = qty.toDoubleOrNull()
            val r = rate.toDoubleOrNull()
            if (product.isNotBlank() && q != null && q > 0 && r != null && r >= 0) {
                lines = lines + InvoiceLine(product.trim(), q, r)
                product = ""; qty = "1"; rate = "0"
            } else Toast.makeText(context, "Enter a product, valid quantity and rate", Toast.LENGTH_SHORT).show()
        }, modifier = Modifier.fillMaxWidth()) { Text("Add item") }

        lines.forEachIndexed { index, line ->
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(line.name, fontWeight = FontWeight.SemiBold)
                        Text("${line.qty} × ₹${"%.2f".format(line.rate)} = ₹${"%.2f".format(line.amount)}")
                    }
                    TextButton(onClick = { lines = lines.filterIndexed { i, _ -> i != index } }) { Text("Remove") }
                }
            }
        }
        OutlinedTextField(discount, { discount = it }, label = { Text("Discount ₹ (invoice level)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(gst, { gst = it }, label = { Text("GST rate % (single rate for all items)") }, modifier = Modifier.fillMaxWidth())
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                SummaryRow("Subtotal", subtotal)
                SummaryRow("Discount", -discountValue)
                SummaryRow("Taxable value", taxable)
                SummaryRow("GST ($gstRate%)", tax)
                HorizontalDivider()
                SummaryRow("GRAND TOTAL", total, true)
                Text("GST split (CGST + SGST) or IGST depends on place of supply; verify before issuing.", style = MaterialTheme.typography.bodySmall)
            }
        }
        Button(onClick = {
            if (seller.isBlank() || buyer.isBlank() || lines.isEmpty()) {
                Toast.makeText(context, "Enter seller, buyer and at least one item", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    createInvoicePdf(context, seller, sellerGstin, buyer, buyerGstin, invoiceNo, date, place, lines, subtotal, discountValue, taxable, gstRate, tax, total)
                    Toast.makeText(context, "Invoice PDF saved in Downloads", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "PDF error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Save invoice as PDF") }
        Text("Setup tip: replace the sample business name and enter your GSTIN before billing.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun SummaryRow(label: String, amount: Double, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text("₹${"%.2f".format(amount)}", fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

fun createInvoicePdf(
    context: android.content.Context, seller: String, sellerGstin: String, buyer: String,
    buyerGstin: String, invoiceNo: String, date: String, place: String, lines: List<InvoiceLine>,
    subtotal: Double, discount: Double, taxable: Double, gstRate: Double, tax: Double, total: Double
) {
    val pdf = PdfDocument()
    val page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, 1).create())
    val canvas = page.canvas
    val paint = Paint().apply { textSize = 12f }
    var y = 55f
    fun line(s: String, size: Float = 12f, bold: Boolean = false) {
        paint.textSize = size; paint.isFakeBoldText = bold
        canvas.drawText(s.take(90), 40f, y, paint); y += size + 10f
    }
    line("TAX INVOICE", 22f, true)
    line(seller, 16f, true)
    line("Seller GSTIN: ${sellerGstin.ifBlank { "Not entered" }}")
    line("Invoice No: $invoiceNo     Date: $date")
    line("Bill To: $buyer")
    line("Buyer GSTIN: ${buyerGstin.ifBlank { "Not entered" }}")
    line("Place of Supply: ${place.ifBlank { "Not entered" }}")
    y += 12f
    line("ITEM                          QTY       RATE          AMOUNT", 11f, true)
    lines.forEach { line("${it.name}       ${it.qty}       ${"%.2f".format(it.rate)}       ${"%.2f".format(it.amount)}") }
    y += 14f
    line("Subtotal: Rs. ${"%.2f".format(subtotal)}")
    line("Discount: Rs. ${"%.2f".format(discount)}")
    line("Taxable value: Rs. ${"%.2f".format(taxable)}")
    line("GST (${gstRate}%): Rs. ${"%.2f".format(tax)}")
    line("TOTAL: Rs. ${"%.2f".format(total)}", 16f, true)
    line("Thank you for your business.")
    pdf.finishPage(page)
    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, "$invoiceNo.pdf")
        put(MediaStore.Downloads.MIME_TYPE, "application/pdf")
        put(MediaStore.Downloads.RELATIVE_PATH, "Download")
    }
    val uri = context.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
        ?: throw IllegalStateException("Could not create PDF file")
    context.contentResolver.openOutputStream(uri)?.use { pdf.writeTo(it) }
    pdf.close()
}
